$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Cat.feature");
formatter.feature({
  "line": 1,
  "name": "Verify All Categories in response",
  "description": "",
  "id": "verify-all-categories-in-response",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 4,
  "name": "All categories in B\u0026O",
  "description": "",
  "id": "verify-all-categories-in-response;all-categories-in-b\u0026o",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 3,
      "name": "@Chrome"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "launch  the uri",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "user validate the response",
  "keyword": "Then "
});
formatter.match({
  "location": "AllCategoriesStep.launch_the_uri()"
});
formatter.result({
  "duration": 10039500938,
  "status": "passed"
});
formatter.match({
  "location": "AllCategoriesStep.user_validate_the_response()"
});
formatter.result({
  "duration": 57253,
  "status": "passed"
});
});