package tetsCases;

import org.testng.annotations.Test;


import baseMethod.Webservices;
import io.restassured.response.Response;
import restUtils.EndpointURL;
import restUtils.URL;




public class CategoriesTest {

	Response response;
	@Test()
	public void verifyGetCountries(){
		//Gson gson = new GsonBuilder().create();
	  //  GetCountries[] getCountries;
	
		String url = URL.fixURL+EndpointURL.GET_CAT.getResourcePath();
		//System.out.println(url);
		response = Webservices.Get(url);
		System.out.println(response.asString());
		if(response.getStatusCode()==200){
			response.prettyPrint();
			
		}
		
}}
