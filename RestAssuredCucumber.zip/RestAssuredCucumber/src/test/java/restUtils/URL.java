package restUtils;

public class URL {

	public static final String fixURL ="https://beoecommerceapimanagement-q1-qa.azure-api.net";

	 //String sepakerCat="/api/cms/v1/category/detail/Speakers";
	
}
