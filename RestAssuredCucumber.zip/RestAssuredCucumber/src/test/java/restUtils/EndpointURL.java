package restUtils;

public enum EndpointURL {

	GET_CAT("/api/cms/v1/category/detail/speakers"),
	CREATECART("/api/cms/v1/cart");
	//GET_COUNTRY_BY_ID("/country/"),
	//DELETE_COUNTRY("/country/"),
	//GET_COUNTRIES("/countries");
	
	String resourcePath;
	
	EndpointURL(String resourcePath){
		this.resourcePath = resourcePath;
		}
	
	public String getResourcePath() {
		return this.resourcePath;
		}
	
	public String getResourcePath(String data) {
		//System.out.println(this.resourcePath);
		return this.resourcePath+data;
		}
	
	
}
