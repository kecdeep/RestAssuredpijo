/*package restUtils;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.cucumber.listener.Reporter;

import baseMethod.Webservices;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class ValidationAndLogging {
	public static int tcFlagStatus=0;
	Response response;
	public void writeresult(String jsonRespose,String josnExpected){
		
		if(!jsonRespose.equals(josnExpected)){

		Reporter.addStepLog("<span style='color:#FF0000'>Failed Step | actual result :" + jsonRespose.toString() + "</span>");                  
			                  tcFlagStatus++;  }
			           else
			                  Reporter.addStepLog("Passed Step | actual result :" + josnExpected);

		}


		public String getStringResponse(String Actualjson, String expectedJson , String method){
			StringBuffer buffer = new StringBuffer(URL.fixURL);
			//String url = URL.fixURL+method;
		 // default size 16
			StringBuffer  ass=buffer.append(method);
			String url=ass.toString();
			//System.out.println(url);
			response = Webservices.Get(url);
			System.out.println(response.asString());
		response = Webservices.Get(url);

		try{
		JsonPath jsonPathEvaluator = response.jsonPath();
			 Actualjson=jsonPathEvaluator.getString("cards[0].item[0].variants[0].productId");
		writeresult(Actualjson.toString(),expectedJson);

		return Actualjson;}
		catch(Exception e)
		{

			writeresult();

		return ""; 	 	

		}
		
}
		public void writeresult(){
			

			Reporter.addStepLog("<span style='color:#FF0000'>Failed Step | actual result :");                  
				                  tcFlagStatus++;  
				          

			}}*/