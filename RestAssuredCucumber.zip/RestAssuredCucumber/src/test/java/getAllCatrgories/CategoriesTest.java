/*package getAllCatrgories;

import org.testng.annotations.Test;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import baseMethod.Webservices;
import io.restassured.response.Response;
import restUtils.EndpointURL;
import restUtils.URL;




public class CategoriesTest {

	Response response;
	@Test()
	public void verifyGetCountries(){
		//Gson gson = new GsonBuilder().create();
	  //  GetCountries[] getCountries;
		String url = URL.fixURL+EndpointURL.AllCategories.getResourcePath();
		//System.out.println(url);
		response = Webservices.Get(url);
		System.out.println(response.asString());
		if(response.getStatusCode()==200){
			response.prettyPrint();
			
		}
		
}}
*/