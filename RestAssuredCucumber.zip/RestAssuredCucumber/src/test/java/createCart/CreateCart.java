package createCart;

import java.util.ArrayList;
import java.util.List;




public class CreateCart {
	String currency;
	public List<AddCartParameter> lineItems;
	
	public CreateCart(String currency){
		this.currency=currency;
		lineItems = new ArrayList<AddCartParameter>();
	
	}
	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}
	
	public void addCartVariable(String name, int variantID,int versionId)
	{
		lineItems.add(new AddCartParameter(name, variantID,versionId));
	}

	
}
