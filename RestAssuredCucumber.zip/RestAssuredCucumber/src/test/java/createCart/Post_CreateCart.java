package createCart;

import static io.restassured.RestAssured.given;

import org.testng.annotations.Test;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class Post_CreateCart {

@Test()

public void post(){
	CreateCart st = new CreateCart("GBP");
	st.addCartVariable("",1,1);
	
	Response resp = given().contentType(ContentType.JSON).log().body()
			.body(st).post();
	
	System.out.println("-----------RESPONSE---------------");
	resp.prettyPrint();
}
}
