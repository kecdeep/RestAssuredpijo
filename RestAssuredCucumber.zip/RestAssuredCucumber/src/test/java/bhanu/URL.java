/*package com.bhanu.utills;

public class URL {

	public static final String fixURL = "http://localhost:8080/SpringRestfulWebServicesCRUDExample";
	
	public static final String fixURL1 = "https://www.facebook.com";
}
*/