/*package com.bhanu.utills;

import com.bhanu.webservices.methods.Webservices;

public class WebservicesUtil {
	
	
//	public static void logintoapplication(){
//		
//		String auth = getLogin();
//		Webservices.authToken = auth;
//	}

}*/
