package practiceJson;

import java.util.ArrayList;
import java.util.List;

import createCart.AddCartParameter;

public class AddUser {
String FirstName;
String LastName;
public List<AddAddress> address;
public AddUser(String FirstName,String LastName){
	this.LastName=LastName;
	this.FirstName=FirstName;
	address=new ArrayList<AddAddress>();
	
}
public String getFirstName() {
	return FirstName;
}
public void setFirstName(String firstName) {
	FirstName = firstName;
}
public String getLastName() {
	return LastName;
}
public void setLastName(String lastName) {
	LastName = lastName;
}

public void AddAddressUser(String addres1, String address2, String city) {
	//super();
	address.add(new AddAddress(addres1, address2,city));

}
}
