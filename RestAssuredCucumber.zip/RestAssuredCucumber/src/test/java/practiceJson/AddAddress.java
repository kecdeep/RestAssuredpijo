package practiceJson;

import java.util.ArrayList;
import java.util.List;

public class AddAddress {
String addres1;
String address2;
String city;
List<PinCode> pins;
public AddAddress(String addres1, String address2, String city) {
	//super();
	this.addres1 = addres1;
	this.address2 = address2;
	this.city = city;
	pins=new ArrayList<>();
}
public AddAddress() {
	// TODO Auto-generated constructor stub
}
public String getAddres1() {
	return addres1;
}

public void setAddres1(String addres1) {
	this.addres1 = addres1;
}

public String getAddress2() {
	return address2;
}

public void setAddress2(String address2) {
	this.address2 = address2;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public void addPin(int pin){
	pins.add(new PinCode(pin));
}


}
