package practiceJson;

public class PinCode {
int pin;

public PinCode(int pin) {
	
	this.pin = pin;
}
public int getPin() {
	return pin;
}

public void setPin(int pin) {
	this.pin = pin;
}

}
