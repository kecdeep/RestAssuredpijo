package practiceJson;

import static io.restassured.RestAssured.given;

import org.testng.annotations.Test;

import createCart.CreateCart;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class BasicStructure1 {
	@Test()

	public void post(){
		AddUser st = new AddUser("Deepak","Rai");
	//st.AddAddressUser("delhi", "vaishali", "punjab");
	AddAddress address=new AddAddress("delhi", "vaishali", "punjab");
	address.addPin(262309);
	st.AddAddressUser("delhi2", "vaishali2", "punjab2");
	

		//st.addCartVariable("",1,1);
		
		Response resp = given().contentType(ContentType.JSON).log().body()
				.body(st).post();
		
		System.out.println("-----------RESPONSE---------------");
		resp.prettyPrint();
}}
