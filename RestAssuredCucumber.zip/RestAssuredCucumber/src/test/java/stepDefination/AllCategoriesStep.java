package stepDefination;

import static io.restassured.RestAssured.given;

import java.util.HashMap;
import java.util.Map;

import org.json.JSONObject;

import com.cucumber.listener.Reporter;

import baseMethod.Webservices;
import createCart.CreateCart;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import restUtils.EndpointURL;
import restUtils.URL;


public class AllCategoriesStep {
	   CreateCart st ;
	Response response;
@Given("^launch  the uri$")
public void launch_the_uri() throws Throwable {
	
	//val=new ValidationAndLogging();
	//String t=URL.fixURL;
	//val.getStringResponse("cards[0].item[0].variants[0].productId", "123", "/api/cms/v1/category/detail/Speakers");
	//=========working code=====================================
	
	String url = URL.fixURL+EndpointURL.GET_CAT.getResourcePath();
	//System.out.println(url);
	response = Webservices.Get(url);
	System.out.println(response.asString());
	JsonPath jsonPathEvaluator = response.jsonPath();

	 String cat=jsonPathEvaluator.getString("cards[0].item[0].variants[0].productId");
	 Reporter.addStepLog("=================cateory id for pass======================"+cat);

	 String urlPost = URL.fixURL+EndpointURL.CREATECART.getResourcePath();
	 System.out.println("-----------------cart detail--------------"+urlPost);
	 
	   //CreateCart
	   st = new CreateCart("GBP");
		st.addCartVariable(cat,1,1);
		Response resp = given().contentType(ContentType.JSON).header("Ocp-Apim-Subscription-Key","81b05759360e488c82b5e94c0024f1cb").header("country","GB").header("locale","en").log().body()
	    .body(st).post(urlPost);
	
		
		resp.prettyPrint();
		//String p=st.toString();
	Reporter.addStepLog("-----------------"+resp.prettyPrint());

}

@Then("^user validate the response$")
public void user_validate_the_response() throws Throwable {
	if(response.getStatusCode()==201){
		
		Reporter.addStepLog(response.prettyPrint());

		//response.prettyPrint();
		
	}
}

}
