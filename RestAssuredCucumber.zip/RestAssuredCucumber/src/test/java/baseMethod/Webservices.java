package baseMethod;

import static io.restassured.RestAssured.given;

import org.testng.annotations.Test;

import com.cucumber.listener.Reporter;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import restUtils.URL;

public class Webservices {
	public static String authToken;
	//Response response ;

	public static Response Post(String uRI,String stringJSON){
		RequestSpecification requestSpecification = RestAssured.given().body(stringJSON);
		
		requestSpecification.contentType(ContentType.JSON);
		requestSpecification.header("Ocp-Apim-Subscription-Key","81b05759360e488c82b5e94c0024f1cb");
		// Reporter.addStepLog(requestSpecification.header("country","GB"));

		requestSpecification.header("country","GB");
		requestSpecification.header("locale","en");
		

		Response response = requestSpecification.post(uRI);
		return response;
	}
	
	public static Response Get(String uRI){
		RequestSpecification requestSpecification = RestAssured.given();
		requestSpecification.contentType(ContentType.JSON);
		requestSpecification.header("Ocp-Apim-Subscription-Key","81b05759360e488c82b5e94c0024f1cb");

		Response response = requestSpecification.get(uRI);
		//requestSpecification.header("Ocp-Apim-Subscription-Key","927de4a6def547db88a20cbd0768c3e9");
		//Response resp = given().contentType(ContentType.JSON).header("Ocp-Apim-Subscription-Key","927de4a6def547db88a20cbd0768c3e9").log().body().get(testprop.getProperty("key"));				//.get(testprop.getProperty(logintest));

		return response;
	}
	
	public static Response Put(String uRI,String stringJSON){
		RequestSpecification requestSpecification = RestAssured.given().body(stringJSON);
		requestSpecification.contentType(ContentType.JSON);
		Response response = requestSpecification.put(uRI);
		return response;
	}
	
	public static Response Delete(String uRI){
		RequestSpecification requestSpecification = RestAssured.given();
		requestSpecification.contentType(ContentType.JSON);
		Response response = requestSpecification.delete(uRI);
		return response;
	}

	public static Response PostCallWithHeader(String uRI,String stringJSON){
		RequestSpecification requestSpecification = RestAssured.given().body(stringJSON);
		requestSpecification.contentType(ContentType.JSON);
		requestSpecification.headers("Authorization", authToken);
		Response response = requestSpecification.post(uRI);
		return response;
	}
	
	public static Response GetCallwithheader(String uRI){
		RequestSpecification requestSpecification = RestAssured.given();
		requestSpecification.headers("Authorization", authToken);
		requestSpecification.headers("companyid", 101);
		requestSpecification.contentType(ContentType.JSON);
		Response response = requestSpecification.get(uRI);
		return response;
	}
	
	public static Response PutCallWithHeader(String uRI,String stringJSON){
		RequestSpecification requestSpecification = RestAssured.given().body(stringJSON);
		requestSpecification.headers("Authorization", authToken);
		requestSpecification.headers("companyid", 101);
		requestSpecification.contentType(ContentType.JSON);
		Response response = requestSpecification.put(uRI);
		return response;
	}
	
	public static Response DeleteCallWitHeader(String uRI){
		RequestSpecification requestSpecification = RestAssured.given();
		requestSpecification.headers("Authorization", authToken);
		requestSpecification.headers("companyid", 101);
		requestSpecification.contentType(ContentType.JSON);
		Response response = requestSpecification.delete(uRI);
		return response;
	}

	/*public static void ValidationGetStatus(String uri,int status){
		given()
		.get(URL.fixURL+uri).then().assertThat().statusCode(status).log().all();
		
		

	}*/
	//public static void loginToApplication(String uRI, String userName, String password) throws JSONException{
		//RequestSpecification requestSpecification = RestAssured.given().auth().form(userName, password);
		//Response response = requestSpecification.get(uRI);
		//org.json.JSONObject jsonObject = new org.json.JSONObject(response);
		//String auth = jsonObject.getString("authToken");
		//authToken = auth;
	//}
}
