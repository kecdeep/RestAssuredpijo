package Runner;


import java.io.File;

import org.junit.AfterClass;
import org.junit.runner.RunWith;

import com.cucumber.listener.Reporter;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import cucumber.api.testng.AbstractTestNGCucumberTests;


@RunWith(Cucumber.class)

@CucumberOptions(
		features ={"RestFeature"},
		format={"html:test-outout", "json:json_output/cucumber.json", "junit:junit_xml/cucumber.xml"},
		glue={"stepDefination"}, //the path of the step definition files
		plugin = {"com.cucumber.listener.ExtentCucumberFormatter:target/cucumber-reports/ExtentReport.html"},
		monochrome = true, //display the console output in a proper readable format
		//plugin = {"com.cucumber.listener.ExtentCucumberFormatter:target/cucumber-reports/report.html"} ,
		strict = true, //it will check if any step is not defined in step definition file
		dryRun = false,//to check the mapping is proper between feature file and step def file
		tags ={"@Chrome"}//for execution feature having both tag	
		)

public class TestRunner extends AbstractTestNGCucumberTests{
	@AfterClass
	public static void reportSetup(){
		Reporter.loadXMLConfig(new File(System.getProperty("user.dir")+"\\configs\\extent-config.xml"));
		Reporter.setSystemInfo("64 Bit", "Windows 10");
		Reporter.setSystemInfo("User Name", System.getProperty("user.name"));
		Reporter.setSystemInfo("Time Zone", System.getProperty("user.timezone"));
		Reporter.setSystemInfo("Machine", 	"Windows 7" + "64 Bit");
		Reporter.setSystemInfo("Selenium", "3.11");
		Reporter.setSystemInfo("Maven", "3.1.2");
		Reporter.setSystemInfo("Java Version", "1.8.0_151");
	}

}

//ORed : tags = {"@SmokeTest , @RegressionTest"} -- execute all tests tagged as @SmokeTest OR @RegressionTest
//ANDed : tags = tags = {"@SmokeTest" , "@RegressionTest"} -- execute all tests tagged as @SmokeTest AND @RegressionTest


//C:\\Users\\deepak\\workspace\\May2018\\EcommerceApplication\\Feature\\FeatureFile\\FaceBookUI.feature
